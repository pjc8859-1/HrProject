package cn.storm.dto;

public class Xcxm {
	private String cstandardid;
	private String name;
	private double money;
	private int xcxmid;
	public String getCstandardid() {
		return cstandardid;
	}
	public void setCstandardid(String cstandardid) {
		this.cstandardid = cstandardid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public int getXcxmid() {
		return xcxmid;
	}
	public void setXcxmid(int xcxmid) {
		this.xcxmid = xcxmid;
	}
	
	
	
	
	
	

}
