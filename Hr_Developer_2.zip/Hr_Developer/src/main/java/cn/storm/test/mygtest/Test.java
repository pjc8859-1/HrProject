
package cn.storm.test.mygtest;


public class Test {

	public static void main(String[] args) {
		
//		ApplicationContext ac = new ClassPathXmlApplicationContext("/applicationContext.xml");
//		ConfigFileFirstKindService cffks = (ConfigFileFirstKindService)ac.getBean("configFileFirstKindServiceImpl");
//		StudentService ss = (StudentService)ac.getBean("studentServiceImpl");
//		
//		Student s = new Student();
//		s.setSid(5);
//		s.setSname("张三");
//		s.setSex("男");
//		s.setScore(65);
//		
//		ss.addStudent(s);
//		System.out.println("保存!");
		
		
//		Student s = ss.queryStudentBySid(1);
//		s.setScore(85);
//		
//		int updateResult = ss.modifyStudent(s);
//		System.out.println(updateResult);
//		List<Student> list = ss.queryAllStudent();
//		for (Student student : list) {
//			System.out.println(student.getSname());
//			
//		}
//		System.out.println(ac.getBean("configMajorMapper"));
		
		
		
	}

}




